#include <iostream>
#include <string>
#include "manager.h"
#include "trolley.h"


int main(int arg, const char * argv[]){

    return 0;
}