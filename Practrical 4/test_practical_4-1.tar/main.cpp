#include "tome.h"
#include <cstring>
#include <string>
#include <iostream>

using namespace std;

/*
int main()
{

	string l[10]  = {"Hex Curse", "Summon Ice Golem"};
    string h[10]  = {"Hell Fire", "Volcano ash", "Eternal flames"};
    string x[10];
    tome t("Hexes and Incantations, A Study", 2,"S. Swaddles, D. Pines",l);
    tome c("Plutto ", 2,"S. Swaddles, D. Pines",h);
    tome b("Maximum carnage ", 0,"S. Swaddles, D. Pines",l);
    
  b = c;
  c = c +"Hex Curse";
  cout << c;
  cout << b;

  b = b+"CRazy Spells ";
  cout << b;
    	
	
return 0;	
}*/
